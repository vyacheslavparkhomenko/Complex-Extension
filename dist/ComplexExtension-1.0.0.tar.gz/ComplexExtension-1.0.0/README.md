---ComplexExtension
 |- ComplexExtension
 |  |- __init__.py
 |  |- complex_extension.py
 |- setup.py
 |- README.rst
 |- LICENSE.txt